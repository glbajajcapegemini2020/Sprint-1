package com.capg.bankapp.ui;

import java.util.Scanner;

public class Main {
	Scanner sc = new Scanner(System.in);
	AccountUserUI accountUILink = new AccountUserUI();
	
	public static void main(String[] args) {
		Main main = new Main();
		while(true)
		{
			System.out.println(" ======= MENU ========");
			System.out.println(" 1. Open Account");
			System.out.println(" 2. Close Account");
			System.out.println(" 3. View All Account");
			System.out.println(" 4. Search Account");
			System.out.println(" 5. Policy Console");
			System.out.println(" 6. Account Holder Information");
			
			System.out.println(" 0. Exit");
			
			System.out.println(" \n Enter your choice :- ");
			String a = main.sc.nextLine();
			int choice = Integer.parseInt(a);
			
			
			switch(choice)
			{
				case 1:
					break;
				case 2:
					break;
				case 3:
					break;
				case 4:
					break;
				case 5:
					break;
				case 6:
					main.accountUILink.getAccountHolderInfo();
					break;
					
					
				case 0:
					System.exit(0);
					break;
			
			
			}//end switch
		}//end while
	}//end main
}//end class
