package com.capg.bankapp.model;

public class AccountHolderInfo {
	private String name;
	private String address;
	private String email;
	private String kyc;
	public AccountHolderInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getKyc() {
		return kyc;
	}
	public void setKyc(String kyc) {
		this.kyc = kyc;
	}
	@Override
	public String toString() {
		return "AccountHolderInfo [name=" + name + ", address=" + address + ", email=" + email + ", kyc=" + kyc + "]";
	}
	
}
