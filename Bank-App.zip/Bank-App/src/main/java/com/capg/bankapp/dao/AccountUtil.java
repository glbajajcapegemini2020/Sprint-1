package com.capg.bankapp.dao;

import java.util.ArrayList;
import java.util.List;

import com.capg.bankapp.model.Account;
import com.capg.bankapp.model.AccountHolderInfo;
import com.capg.bankapp.model.Policy;

public class AccountUtil {

	public static List<Account> accountDBList = new ArrayList<Account>();

	static {
		// ---- user 1 information -----

		AccountHolderInfo accountHolderInfo1 = new AccountHolderInfo();
		accountHolderInfo1.setName("Ramesh Kumar");
		accountHolderInfo1.setEmail("ramesh@gmail.com");
		accountHolderInfo1.setAddress("123-New Delhi");
		accountHolderInfo1.setKyc("Passport/PAN");

		Policy p1 = new Policy();
		p1.setPolicyAmount(91);
		p1.setPolicyName("Policy-91");

		Policy p2 = new Policy();
		p1.setPolicyAmount(92);
		p1.setPolicyName("Policy-92");

		List<Policy> policyList101 = new ArrayList<Policy>();
		policyList101.add(p1);
		policyList101.add(p2);

		Account account1 = new Account("saving", 101, 2000, accountHolderInfo1, policyList101);

		// ---- user 2 information -----

		AccountHolderInfo accountHolderInfo2 = new AccountHolderInfo();
		accountHolderInfo1.setName("Jatin");
		accountHolderInfo1.setEmail("jatin@gmail.com");
		accountHolderInfo1.setAddress("123-Noida");
		accountHolderInfo1.setKyc("Passport/PAN");

		Policy p3 = new Policy();
		p1.setPolicyAmount(92);
		p1.setPolicyName("Policy-92");

		List<Policy> policyList102 = new ArrayList<Policy>();
		policyList101.add(p3);

		Account account2 = new Account("saving", 102, 2800, accountHolderInfo2, policyList102);

		accountDBList.add(account1);
		accountDBList.add(account2);
	}

	public static List<Account> getAccontsinit() {
		return accountDBList;
	}

}
