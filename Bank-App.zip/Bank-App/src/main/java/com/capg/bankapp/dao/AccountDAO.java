package com.capg.bankapp.dao;

import java.util.List;

import com.capg.bankapp.exceptions.InvalidAccountNumberException;
import com.capg.bankapp.exceptions.LowBalanceException;
import com.capg.bankapp.model.Account;
import com.capg.bankapp.model.AccountHolderInfo;
import com.capg.bankapp.model.Policy;

public interface AccountDAO {
		public boolean addAccount(Account account) throws LowBalanceException;
		public boolean closeAccount(int accountNumber) throws InvalidAccountNumberException;
		public AccountHolderInfo getAccountHolderInfo(int accountNumber) throws InvalidAccountNumberException;
		public List<Policy> getAccountPolicyInfo(int accountNumber) throws InvalidAccountNumberException;
		public Account getAccountByNumber(int accountNumber) throws InvalidAccountNumberException;
}
