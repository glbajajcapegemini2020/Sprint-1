package com.capg.bankapp.ui;

import java.util.Scanner;

import com.capg.bankapp.exceptions.InvalidAccountNumberException;
import com.capg.bankapp.model.AccountHolderInfo;
import com.capg.bankapp.service.AccountService;
import com.capg.bankapp.service.AccountServiceImpl;

public class AccountUserUI {
	Scanner sc = new Scanner(System.in);
	AccountService accountService;
	// Animal a;
	
	public AccountUserUI() {
		// a = new Dog();
		accountService = new AccountServiceImpl();
	}


	public void getAccountHolderInfo()
	{
		System.out.println("Enter Account Number 101/102");
		int accountNumber = Integer.parseInt(sc.nextLine());
		try {							
			AccountHolderInfo holderInfo = accountService.getAccountHolderInfo(accountNumber);
			System.out.println(holderInfo);
			
		} catch (InvalidAccountNumberException e) {
			System.out.println(e);
		}
		
	}
}
