package com.capg.bankapp.model;

import java.util.List;

public class Account {
	private String accountType;
	private int accountNumber;
	private int balance;
	private AccountHolderInfo accountHolderInfo;
	private List<Policy> policyList;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(String accountType, int accountNumber, int balance, AccountHolderInfo accountHolderInfo,
			List<Policy> policyList) {
		super();
		this.accountType = accountType;
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.accountHolderInfo = accountHolderInfo;
		this.policyList = policyList;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public AccountHolderInfo getAccountHolderInfo() {
		return accountHolderInfo;
	}
	public void setAccountHolderInfo(AccountHolderInfo accountHolderInfo) {
		this.accountHolderInfo = accountHolderInfo;
	}
	public List<Policy> getPolicyList() {
		return policyList;
	}
	public void setPolicyList(List<Policy> policyList) {
		this.policyList = policyList;
	}
	@Override
	public String toString() {
		
		String accinfo = accountNumber+" , "+accountHolderInfo.getName()+" , "+balance+".";
		
		return accinfo;
	}
	
	
}
