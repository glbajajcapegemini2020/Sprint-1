package com.capg.bankapp.service;

import com.capg.bankapp.exceptions.InvalidAccountNumberException;
import com.capg.bankapp.model.AccountHolderInfo;

public interface AccountService {
	public AccountHolderInfo getAccountHolderInfo(int accountNumber)throws InvalidAccountNumberException;
}
