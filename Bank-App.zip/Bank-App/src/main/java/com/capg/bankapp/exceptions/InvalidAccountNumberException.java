package com.capg.bankapp.exceptions;

public class InvalidAccountNumberException extends Exception{

	int accountNumber;
	
	
	
	public InvalidAccountNumberException(int accountNumber) {
		super();
		this.accountNumber = accountNumber;
	}



	@Override
	public String toString() {
		return "InvalidAccountNumberException "+accountNumber;
	}
	
}
