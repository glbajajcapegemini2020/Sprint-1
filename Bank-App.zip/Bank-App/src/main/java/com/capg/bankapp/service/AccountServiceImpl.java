package com.capg.bankapp.service;

import com.capg.bankapp.dao.AccountDAO;
import com.capg.bankapp.dao.AccountDAOImpl;
import com.capg.bankapp.exceptions.InvalidAccountNumberException;
import com.capg.bankapp.model.AccountHolderInfo;

public class AccountServiceImpl implements AccountService {

	AccountDAO accountdao;
	public AccountServiceImpl() {
		accountdao = new AccountDAOImpl();
	}
	
	public AccountHolderInfo getAccountHolderInfo(int accountNumber) throws InvalidAccountNumberException {
		return accountdao.getAccountHolderInfo(accountNumber);
	}

}
