package com.capg.bankapp.dao;

import java.util.List;

import com.capg.bankapp.exceptions.InvalidAccountNumberException;
import com.capg.bankapp.exceptions.LowBalanceException;
import com.capg.bankapp.model.Account;
import com.capg.bankapp.model.AccountHolderInfo;
import com.capg.bankapp.model.Policy;

public class AccountDAOImpl implements AccountDAO {
	
	List<Account> accountDBConnection;
	
	public AccountDAOImpl() {
		accountDBConnection = AccountUtil.getAccontsinit();
	}

	public boolean addAccount(Account account) throws LowBalanceException {
		return false;
	}

	public boolean closeAccount(int accountNumber) throws InvalidAccountNumberException {
		// TODO Auto-generated method stub
		return false;
	}

	public AccountHolderInfo getAccountHolderInfo(int accountNumber) throws InvalidAccountNumberException {
		Account account = getAccountByNumber(accountNumber);
		
		if(account != null)
		{
			return account.getAccountHolderInfo();
		}
		else return null;
	}

	public List<Policy> getAccountPolicyInfo(int accountNumber) throws InvalidAccountNumberException {
		// TODO Auto-generated method stub
		return null;
	}

	public Account getAccountByNumber(int accountNumber) throws InvalidAccountNumberException {
		
		Account searchedAccount = null;
		
		for (Account account : accountDBConnection) {
			if(account.getAccountNumber() == accountNumber)
			{
				searchedAccount = account;
				break;
			}
		}
		
		if(searchedAccount == null)throw new InvalidAccountNumberException(accountNumber);
		return searchedAccount;
	}
	

}
