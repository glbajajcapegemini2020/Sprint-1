package com.capg.bankapp.exceptions;

public class LowBalanceException extends Exception{

}
