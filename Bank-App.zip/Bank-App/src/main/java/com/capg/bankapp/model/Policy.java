package com.capg.bankapp.model;

public class Policy {

	private String policyName;
	private int policyAmount;
	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public int getPolicyAmount() {
		return policyAmount;
	}
	public void setPolicyAmount(int policyAmount) {
		this.policyAmount = policyAmount;
	}
	@Override
	public String toString() {
		return "Policy [policyName=" + policyName + ", policyAmount=" + policyAmount + "]";
	}
	
	
}
